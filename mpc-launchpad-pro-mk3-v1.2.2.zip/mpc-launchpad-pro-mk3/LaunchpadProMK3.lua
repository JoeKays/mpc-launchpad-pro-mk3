local deviceName = "LaunchpadProMK3" -- must match the file name
local port = 0 -- the one LPP3 output (order of output= lines in the .ini)
local dev = LaunchpadProMK3
local GRID_NOTE0 = 11 -- notes 11-88, bottom-left first
local GRID_COLS, GRID_ROWS = 8, 8
local TOP = {
shift = 90,
left = 91,
right = 92,
session = 93,
note = 94,
chord = 95,
custom = 96,
sequencer = 97,
save = 98,
}
local RIGHT = {
logo = 99,
patterns = 89,
steps = 79,
patternSettings = 69,
velocity = 59,
probability = 49,
mutation = 39,
microStep = 29,
printToClip = 19,
}
local LEFT = { record = 10, play = 20, fixedLength = 30, quantize = 40, duplicate = 50, clear = 60, down = 70, up = 80 }
local TRACK = {
recArm = 1,
mute = 2,
solo = 3,
volume = 4,
pan = 5,
sends = 6,
device = 7,
stopClip = 8,
}
local TRACK_FN = {
[TRACK.recArm] = "recArm",
[TRACK.mute] = "mute",
[TRACK.solo] = "solo",
[TRACK.volume] = "volume",
[TRACK.pan] = "pan",
[TRACK.sends] = "sends",
[TRACK.device] = "device",
[TRACK.stopClip] = "stopClip",
}
local SCENE = { 89, 79, 69, 59, 49, 39, 29, 19 }
local ACTIONS = {
[90] = { label = "Shift", plain = "hold for the shift functions", shift = "-" },
[91] = { label = "Left", plain = "move the clip window left", shift = "previous track" },
[92] = { label = "Right", plain = "move the clip window right", shift = "next track" },
[93] = { label = "Session", plain = "clip grid (leaves every page)", shift = "toggle follow-current-track" },
[94] = { label = "Note", plain = "MPC pads mode (layout from the track type)", shift = "previous plugin preset" },
[95] = { label = "Chord", plain = "open the MPC Pad Perform page", shift = "next plugin preset" },
[96] = { label = "Custom", plain = "unmapped stub", shift = "unmapped stub" },
[97] = { label = "Sequencer", plain = "open the MPC step sequencer view", shift = "step sequencer: next bar" },
[98] = { label = "Projects", plain = "unmapped stub", shift = "save" },
[99] = { label = "Logo", plain = "log the current mode", shift = "probe mode (log every incoming message)" },
[89] = { label = "Patterns", plain = "launch scene 1", shift = "scene 1 label function" },
[79] = { label = "Steps", plain = "launch scene 2", shift = "scene 2 label function" },
[69] = { label = "Pattern settings", plain = "launch scene 3", shift = "scene 3 label function" },
[59] = { label = "Velocity", plain = "launch scene 4", shift = "scene 4 label function" },
[49] = { label = "Probability", plain = "launch scene 5", shift = "scene 5 label function" },
[39] = { label = "Mutation", plain = "launch scene 6", shift = "scene 6 label function" },
[29] = { label = "Micro step", plain = "launch scene 7", shift = "scene 7 label function" },
[19] = { label = "Print to clip", plain = "launch scene 8", shift = "scene 8 label function" },
[10] = { label = "Record", plain = "arm / disarm recording", shift = "overdub" },
[20] = { label = "Play", plain = "play / stop", shift = "loop on / off" },
[30] = { label = "Fixed length", plain = "unmapped stub", shift = "cycle the automation filter" },
[40] = { label = "Quantize", plain = "apply quantize", shift = "apply quantize" },
[50] = { label = "Duplicate", plain = "hold: duplicate clip (origin, then target)", shift = "hold: duplicate clip" },
[60] = { label = "Clear", plain = "hold: clear clip", shift = "hold: clear clip" },
[70] = { label = "Down", plain = "window down / page value down", shift = "window down by 8" },
[80] = { label = "Up", plain = "window up / page value up", shift = "window up by 8" },
[1] = { label = "Rec arm", plain = "hold + track: record arm", shift = "undo" },
[2] = { label = "Mute", plain = "hold + track: mute", shift = "redo" },
[3] = { label = "Solo", plain = "hold + track: solo", shift = "-" },
[4] = { label = "Volume", plain = "volume menu", shift = "-" },
[5] = { label = "Pan", plain = "pan menu", shift = "-" },
[6] = { label = "Sends", plain = "sends menu (repeat: next send)", shift = "tap tempo" },
[7] = { label = "Device", plain = "Q-Link page (repeat: page 2, then exit)", shift = "tempo page" },
[8] = { label = "Stop clip", plain = "hold + track: stop the track's clips", shift = "swing page" },
}
local S = {
NoSlot = 0,
Empty = 1,
Ready = 2,
WillPlay = 3,
Playing = 4,
WillStopPlaying = 5,
WillRecord = 6,
Recording = 7,
WillStopRecording = 8,
WillOverdub = 9,
Overdubbing = 10,
WillStopOverdubbing = 11,
}
local C = {
off = { 0, 0, 0 },
dim = { 12, 12, 12 },
available = { 60, 60, 60 },
white = { 127, 127, 127 },
green = { 0, 127, 0 },
red = { 127, 0, 0 },
orange = { 127, 60, 0 },
blue = { 0, 60, 127 },
cyan = { 0, 127, 127 },
magenta = { 127, 0, 127 },
yellow = { 127, 127, 0 },
}
local VOLUME_DB = { [7] = -100, [6] = -30, [5] = -20, [4] = -9, [3] = -3, [2] = 0, [1] = 3, [0] = 6 }
local SEND_COLOURS = { C.yellow, C.green, C.blue, C.orange }
local aperture, clipProps
local shift = false
local mode = "clip" -- clip / transport / track / probe
local originCol, originRow = 0, 0
local padCache = {} -- LED index -> "r,g,b" last sent
local ledSpecs = {} -- accumulated specs for the current flush
local ticks = 0
local blinkOn = false
local probeMode = false
local heldFunction = nil
local adjustMode = nil -- nil / "volume" / "pan" / "sends" (menu mode)
local adjustSend = 1 -- 1..4, the active send in sends mode
local adjustCol = 0 -- last grid column touched in the menu (for up/down nudges)
local lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
local clipOp = nil -- nil / "duplicate" / "clear"
local clipOrigin = nil -- {col, row} for duplicate
local tempoMode = false -- Shift+CC7 tempo page: up/down change BPM
local tempoHold = nil -- LEFT.up / LEFT.down while held (auto-repeat)
local tempoHoldTicks = 0 -- ticks since the tempo button was pressed
local swingMode = false -- Shift+CC8 swing page: up/down change swing
local swingHold = nil -- LEFT.up / LEFT.down while held (auto-repeat)
local swingHoldTicks = 0 -- ticks since the swing button was pressed
local qlinkMode = false -- CC7 device page: Q-Link faders (Twist-driven)
local qlinkPage = 0 -- 0 = Q-Links 0-7, 1 = Q-Links 8-15
local qlinkCol = 0 -- last grid column touched (for Shift+up/down nudges)
local followMode = false -- optional grid-follows-current-track; Shift+CC 93 toggles
local padsMode = false -- CC94 MPC pads mode: the grid quadrant mirrors mpc.controlSurface.pads
local padsColourCache = {} -- pad index -> ARGB int last sent (diff-only mirror)
local tapTicks = {} -- recent tap-tempo tick timestamps (50 ms per tick)
local padsLayout = "drum" -- CC 94 mode layout: drum (4x4 bank A) or pads64 (all four banks)
local boundPadNotes = {} -- grid notes currently routed away from the script
local chromaticVirtualPad -- forward declaration (defined with the pad-mode helpers)
local nativeTap = false -- Shift held + CC 6 routed to the MPC's Tap Tempo control
local priorLayout, priorPage = nil, nil
local programmerEntered = false
local layoutQuerySent = false
local lastLog = {}
local H = {}
function H.log(msg)
pcall(function()
print(deviceName .. ": " .. tostring(msg))
end)
end
function H.logOnce(key, msg)
if lastLog[key] then
return
end
lastLog[key] = true
H.log(msg)
end
function H.call(f, ...)
if type(f) ~= "function" then
return nil
end
local ok, r = pcall(f, ...)
if ok then
return r
end
return nil
end
function H.propValue(obj, name)
local p = obj and obj[name]
if p == nil then
return nil
end
local ok, v = pcall(function()
return p.value
end)
if ok then
return v
end
return nil
end
function H.truthy(v)
return v ~= nil and v ~= false and v ~= 0
end
function H.member(obj, key, kind)
if obj == nil then
return nil
end
local v = obj[key]
if v ~= nil and (kind == nil or type(v) == kind) then
return v
end
return nil
end
function H.callable(obj, key)
return H.member(obj, key, "function")
end
function H.trackAction(field, logKey, label)
local ct = mpc.tracks and mpc.tracks.currentTrack
local f = H.callable(ct, field)
if not f then
H.logOnce(logKey, label .. " unavailable: currentTrack." .. field .. " missing")
return false
end
H.call(f)
return true
end
function H.currentPopup()
local em = mpc.engineMode
local p = H.propValue(em, "CurrentPopup")
if p == nil then
p = H.call(H.callable(em, "GetCurrentPopup"))
end
return tostring(p or "")
end
function H.popupOpen()
local p = H.currentPopup()
return p ~= "" and p ~= "No Popup"
end
function H.projectLoaded()
if H.popupOpen() then
return false
end
if mpc.currentSequence ~= nil then
return true
end
local tracks = mpc.tracks
if tracks ~= nil and tracks.currentTrack ~= nil then
return true
end
local bpm = H.call(H.callable(mpc.sequencer, "GetBPM"))
if type(bpm) == "number" and bpm > 0 then
return true
end
return false
end
function H.requireProject(label)
if H.projectLoaded() then
return true
end
if H.popupOpen() then
H.logOnce(label .. "-popup", label .. ": dialog open (" .. H.currentPopup() .. ")")
else
H.logOnce(label .. "-noproject", label .. ": no project loaded")
end
return false
end
function H.clamp01(v)
v = tonumber(v) or 0
if v < 0 then
return 0
elseif v > 1 then
return 1
end
return v
end
function H.dbToRow(db)
db = tonumber(db)
if db == nil or db <= -60 then
return 7
elseif db <= -25 then
return 6
elseif db <= -14.5 then
return 5
elseif db <= -6 then
return 4
elseif db <= -1.5 then
return 3
elseif db <= 1.5 then
return 2
elseif db <= 4.5 then
return 1
end
return 0
end
function H.dbToGain(db)
db = tonumber(db)
if db == nil or db <= -60 then
return 0
end
return 10 ^ ((db - 6) / 40)
end
function H.gainToDb(gain)
gain = tonumber(gain)
if gain == nil or gain <= 0 then
return -100
end
return 40 * math.log(gain, 10) + 6
end
function H.trackAt(idx)
return mpc.tracks and mpc.tracks.normalTracks and mpc.tracks.normalTracks[idx]
end
function H.adjustPropName()
if adjustMode == "volume" then
return "Volume"
elseif adjustMode == "pan" then
return "Pan"
elseif adjustMode == "sends" then
return "Send" .. adjustSend
end
return nil
end
function H.adjustColour()
if adjustMode == "pan" then
return C.magenta
elseif adjustMode == "sends" then
return SEND_COLOURS[adjustSend] or C.yellow
end
return C.cyan
end
function H.argb(c)
c = tonumber(c) or 0
return math.floor(c / 65536) % 256, math.floor(c / 256) % 256, c % 256
end
function H.scale7(v)
v = tonumber(v) or 0
if v < 0 then
v = 0
elseif v > 255 then
v = 255
end
return math.floor(v * 127 / 255)
end
function H.rgbKey(r, g, b)
return r .. "," .. g .. "," .. b
end
function H.globalPos(col, row)
if aperture then
local gc = H.call(aperture.ToGlobalColumn, col)
local gr = H.call(aperture.ToGlobalRow, row)
if type(gc) == "number" and type(gr) == "number" then
return gc, gr
end
end
return col + (originCol or 0), row + (originRow or 0)
end
local function clipStatus(col, row)
local m = mpc.clipMatrix
if not (m and m.HasClip) then
return 0
end
local gc, gr = H.globalPos(col, row)
local has = H.call(m.HasClip, gc, gr)
if not has then
return 0, gc, gr
end
if H.call(m.ClipIsPlaying, gc, gr) or H.call(m.ClipIsRecording, gc, gr) then
return 2, gc, gr
end
if H.call(m.ClipIsStopped, gc, gr) then
return 1, gc, gr
end
return 3, gc, gr
end
local function clipColour(col, row)
local p = clipProps and clipProps[col] and clipProps[col][row]
local c = H.propValue(p, "Colour")
if type(c) == "number" and c ~= 0 then
return c
end
local m = mpc.clipMatrix
if m and m.GetClipColour then
local gc, gr = H.globalPos(col, row)
local v = H.call(m.GetClipColour, gc, gr)
if type(v) == "number" then
return v
end
end
return 0x808080
end
local function addSpec(spec)
ledSpecs[#ledSpecs + 1] = spec
end
local function ledRGB(index, r, g, b)
index = tonumber(index)
if not index then
return
end
r, g, b = math.floor(tonumber(r) or 0), math.floor(tonumber(g) or 0), math.floor(tonumber(b) or 0)
if r < 0 then
r = 0
elseif r > 127 then
r = 127
end
if g < 0 then
g = 0
elseif g > 127 then
g = 127
end
if b < 0 then
b = 0
elseif b > 127 then
b = 127
end
local key = H.rgbKey(r, g, b)
if padCache[index] == key then
return
end
padCache[index] = key
addSpec(string.char(3, index % 128, r, g, b))
end
local function ledCol(index, colour)
ledRGB(index, colour[1], colour[2], colour[3])
end
local function ledOff(index)
ledRGB(index, 0, 0, 0)
end
local function flushLEDs()
if #ledSpecs == 0 then
return
end
local header = string.char(0x00, 0x20, 0x29, 0x02, 0x0E, 0x03)
local ok = pcall(function()
dev.midiOut.SendMIDISysex(header .. table.concat(ledSpecs), port)
end)
if not ok then
H.logOnce("sysex", "SendMIDISysex failed")
end
ledSpecs = {}
end
local function sendLayout(layout, page)
local ok = pcall(function()
dev.midiOut.SendMIDISysex(string.char(0x00, 0x20, 0x29, 0x02, 0x0E, 0x00, layout, page, 0x00), port)
end)
if not ok then
H.logOnce("layout", "layout sysex failed")
end
end
local function queryLayout()
local ok = pcall(function()
dev.midiOut.SendMIDISysex(string.char(0x00, 0x20, 0x29, 0x02, 0x0E, 0x00), port)
end)
if not ok then
H.logOnce("layoutq", "layout query failed")
end
end
local SEGMENTS = {
["0"] = { a = true, b = true, c = true, d = true, e = true, f = true, g = false },
["1"] = { a = false, b = true, c = true, d = false, e = false, f = false, g = false },
["2"] = { a = true, b = true, c = false, d = true, e = true, f = false, g = true },
["3"] = { a = true, b = true, c = true, d = true, e = false, f = false, g = true },
["4"] = { a = false, b = true, c = true, d = false, e = false, f = true, g = true },
["5"] = { a = true, b = false, c = true, d = true, e = false, f = true, g = true },
["6"] = { a = true, b = false, c = true, d = true, e = true, f = true, g = true },
["7"] = { a = true, b = true, c = true, d = false, e = false, f = false, g = false },
["8"] = { a = true, b = true, c = true, d = true, e = true, f = true, g = true },
["9"] = { a = true, b = true, c = true, d = true, e = false, f = true, g = true },
}
local function tempoPad(col, row, colour)
if col >= 0 and col < GRID_COLS and row >= 0 and row < GRID_ROWS then
ledRGB(10 * (8 - row) + col + 1, colour[1], colour[2], colour[3])
end
end
local function drawDigit(ch, x0, y0, w, h, colour)
local seg = SEGMENTS[ch]
if not seg then
return
end
local mid = math.floor(h / 2)
if seg.a then
for c = 0, w - 1 do
tempoPad(x0 + c, y0, colour)
end
end
if seg.d then
for c = 0, w - 1 do
tempoPad(x0 + c, y0 + h - 1, colour)
end
end
if seg.g then
for c = 0, w - 1 do
tempoPad(x0 + c, y0 + mid, colour)
end
end
if seg.f then
for r = 0, mid do
tempoPad(x0, y0 + r, colour)
end
end
if seg.b then
for r = 0, mid do
tempoPad(x0 + w - 1, y0 + r, colour)
end
end
if seg.e then
for r = mid, h - 1 do
tempoPad(x0, y0 + r, colour)
end
end
if seg.c then
for r = mid, h - 1 do
tempoPad(x0 + w - 1, y0 + r, colour)
end
end
end
local function paintNumberGrid(value)
value = math.max(0, math.min(999, math.floor(value)))
for row = 0, GRID_ROWS - 1 do
for col = 0, GRID_COLS - 1 do
ledOff(10 * (8 - row) + col + 1)
end
end
local text
local widths = {}
if value >= 100 then
text = string.format("%3d", value)
widths[1] = (text:sub(1, 1) == "1") and 1 or 2
local remaining = GRID_COLS - widths[1]
widths[2] = math.floor(remaining / 2)
widths[3] = remaining - widths[2]
else
text = string.format("%2d", value)
widths[1] = 4
widths[2] = 4
end
local colours = { C.white, C.orange, C.blue }
local x0 = 0
for i = 1, #text do
drawDigit(text:sub(i, i), x0, 0, widths[i], GRID_ROWS, colours[#text - i + 1])
x0 = x0 + widths[i]
end
end
local function paintTempoGrid()
local bpm = math.floor(H.call(mpc.sequencer and mpc.sequencer.GetBPM) or 120)
paintNumberGrid(bpm)
end
local function paintSwingGrid()
local q = mpc.sequencer and mpc.sequencer.quantiser
local swing = math.floor(H.call(q and q.GetSwing) or 50)
paintNumberGrid(math.max(50, math.min(75, swing)))
end
local function paintAdjustGrid()
local colour = C.cyan
if adjustMode == "pan" then
colour = C.magenta
elseif adjustMode == "sends" then
colour = SEND_COLOURS[adjustSend] or C.yellow
end
local name = H.adjustPropName()
local trackCount = H.call(mpc.tracks and mpc.tracks.SizeNormalTracks) or GRID_COLS
for col = 0, GRID_COLS - 1 do
local gc = H.globalPos(col, 0)
local t = H.trackAt(gc)
if t and gc < trackCount then
local litCount
if adjustMode == "volume" then
local gain = H.propValue(t, "Volume")
local db = H.gainToDb(gain)
local row = H.dbToRow(db)
litCount = (db <= -60) and 0 or (GRID_ROWS - row)
else
local value = H.propValue(t, name) or 0
if type(value) ~= "number" then
value = 0
end
litCount = math.floor(value * GRID_ROWS + 0.5)
end
for row = 0, GRID_ROWS - 1 do
local idx = 10 * (8 - row) + col + 1
local fromBottom = 7 - row
if fromBottom < litCount then
ledCol(idx, colour)
else
ledCol(idx, C.dim)
end
end
else
for row = 0, GRID_ROWS - 1 do
ledOff(10 * (8 - row) + col + 1)
end
end
end
end
local paintAll -- forward declaration (defined below)
local function qlinkAt(i)
local cs = mpc.controlSurface
local ql = cs and cs.qlinks
if not ql then
return nil
end
return ql[i]
end
local function qlinkCount()
local cs = mpc.controlSurface
local ql = cs and cs.qlinks
if not ql then
return 0
end
return H.call(ql.GetNumQLinks) or 0
end
local function qlinkPosition(i)
local q = qlinkAt(i)
if not q then
return 0
end
return H.call(q.GetPosition) or 0
end
local function touchQlink(q)
if q and type(q.Touch) == "function" then
pcall(q.Touch)
end
end
local qlinkTargetLogged = {} -- page-open diagnosis: one line per qlink
local QLINK_BANK_COLOURS = { C.cyan, C.magenta, C.yellow, C.blue }
local qlinkFlip = {}
local qlinkSeenStrings = {} -- i -> set of distinct value strings observed
local qlinkSeenPos = {} -- i -> { min = , max = }
local function qlinkTargetName(i)
local q = qlinkAt(i)
local name = H.call(q and q.GetTargetName)
if type(name) ~= "string" then
name = H.propValue(q, "TargetName")
end
return type(name) == "string" and name or ""
end
local function setQlinkPosition(i, pos)
local q = qlinkAt(i)
if not q then
return
end
if not qlinkTargetLogged[i] then
qlinkTargetLogged[i] = true
H.log(string.format("qlink %d target '%s'", i, qlinkTargetName(i)))
end
local before = H.call(q.GetValueString)
local posBefore = H.call(q.GetPosition) or 0
touchQlink(q)
if type(q.Twist) == "function" then
for _ = 1, 2 do
local delta = pos - (H.call(q.GetPosition) or 0)
if delta == 0 then
break
end
if delta > 127 then
delta = 127
elseif delta < -127 then
delta = -127
end
H.call(q.Twist, delta)
end
end
local afterTwist = H.call(q.GetValueString)
if afterTwist == before and type(q.SetValue) == "function" then
local v = H.call(q.GetValue)
if type(v) == "number" and posBefore ~= 0 then
H.call(q.SetValue, v * pos / posBefore)
end
H.call(q.SetPosition, pos)
elseif type(q.SetPosition) == "function" then
H.call(q.SetPosition, pos) -- keep the knob position in sync with the target
end
touchQlink(q)
local str = tostring(H.call(q.GetValueString) or "")
H.log(string.format("qlink %d = %d (%s)", i, pos, str))
if str ~= "" then
local seen = qlinkSeenStrings[i]
if not seen then
seen = {}
qlinkSeenStrings[i] = seen
end
seen[str] = true
local span = qlinkSeenPos[i]
if not span then
span = { min = pos, max = pos }
qlinkSeenPos[i] = span
else
if pos < span.min then
span.min = pos
end
if pos > span.max then
span.max = pos
end
end
local n = 0
for _ in pairs(seen) do
n = n + 1
end
if n == 2 and span.max - span.min >= 48 and not qlinkFlip[i] then
qlinkFlip[i] = true
H.log(string.format("qlink %d flip parameter", i))
end
end
end
local function qlinkAssigned(i)
return qlinkTargetName(i) ~= ""
end
local function qlinkColour(i)
return QLINK_BANK_COLOURS[math.floor(i / 4) + 1] or C.cyan
end
local QLINK_PAGE_GROUPS = {
[0] = { { 12, 8, 4, 0 }, { 13, 9, 5, 1 } }, -- MPC pages 1+2
[1] = { { 14, 10, 6, 2 }, { 15, 11, 7, 3 } }, -- MPC pages 3+4
}
local qlinkColumnMap = {}
local function buildQlinkColumnMap(page)
qlinkColumnMap = {}
local count = qlinkCount()
local groups = QLINK_PAGE_GROUPS[page or qlinkPage] or QLINK_PAGE_GROUPS[0]
for g = 1, 2 do
for rank, i in ipairs(groups[g]) do
if i < count and qlinkAssigned(i) then
qlinkColumnMap[4 * (g - 1) + rank - 1] = i
end
end
end
end
local function qlinkForColumn(col)
return qlinkColumnMap[col]
end
local function qlinkPageHasContent(page)
local count = qlinkCount()
for _, group in ipairs(QLINK_PAGE_GROUPS[page]) do
for _, i in ipairs(group) do
if i < count and qlinkAssigned(i) then
return true
end
end
end
return false
end
local function paintQlinkGrid()
buildQlinkColumnMap()
for col = 0, GRID_COLS - 1 do
local i = qlinkForColumn(col)
local assigned = i ~= nil
local pos = assigned and qlinkPosition(i) or 0
local colour = qlinkColour(i or 0)
local litCount = math.floor(pos / 127 * GRID_ROWS + 0.5)
for row = 0, GRID_ROWS - 1 do
local idx = 10 * (8 - row) + col + 1
local fromBottom = 7 - row
if not assigned then
ledOff(idx)
elseif qlinkFlip[i] then
if (pos >= 64 and row == 0) or (pos < 64 and row == GRID_ROWS - 1) then
ledCol(idx, colour)
else
ledCol(idx, C.dim)
end
elseif fromBottom < litCount then
ledCol(idx, colour)
else
ledCol(idx, C.dim)
end
end
end
end
local function handleQlinkPad(col, row)
buildQlinkColumnMap()
local i = qlinkForColumn(col)
if i == nil then
return
end
local target
if qlinkFlip[i] then
target = (row < GRID_ROWS / 2) and 127 or 0
else
target = math.floor((GRID_ROWS - row) / GRID_ROWS * 127 + 0.5)
end
setQlinkPosition(i, target)
qlinkCol = col
paintAll()
end
local function nudgeQlink(delta)
buildQlinkColumnMap()
local i = qlinkForColumn(qlinkCol)
local q = qlinkAt(i)
if not q or type(q.Twist) ~= "function" or i >= qlinkCount() then
return
end
local pos = qlinkPosition(i)
if pos + delta < 0 or pos + delta > 127 then
return
end
H.call(q.Twist, delta)
H.log(string.format("qlink %d = %d (%s)", i, pos + delta, tostring(H.call(q.GetValueString) or "")))
paintAll()
end
local function enterQlink()
if not H.requireProject("qlink page") then
return
end
local cs = mpc.controlSurface
if not (cs and cs.qlinks) then
H.logOnce("noqlinks", "qlink page unavailable: controlSurface.qlinks missing")
return
end
adjustMode = nil
tempoMode = false
swingMode = false
qlinkMode = true
qlinkPage = 0
qlinkCol = 0
qlinkTargetLogged = {}
qlinkFlip = {}
qlinkSeenStrings = {}
qlinkSeenPos = {}
buildQlinkColumnMap(0)
local map = {}
local assignedCount = 0
for c = 0, GRID_COLS - 1 do
local i = qlinkColumnMap[c]
if i then
assignedCount = assignedCount + 1
map[#map + 1] = (c + 1) .. "=" .. qlinkTargetName(i)
else
map[#map + 1] = (c + 1) .. "=-"
end
end
H.log("qlink page (" .. assignedCount .. " assigned): " .. table.concat(map, ", "))
paintAll()
end
local function exitQlink()
qlinkMode = false
H.log("qlink page off")
paintAll()
end
local CLIP_BLINK_FAST = { [3] = true, [5] = true, [6] = true, [8] = true, [9] = true, [11] = true }
local function blinkPhase(fast)
if fast then
return blinkOn
end
return ticks % 10 < 5
end
local function paintClipSlot(col, row)
local p = clipProps and clipProps[col] and clipProps[col][row]
local state = tonumber(H.propValue(p, "State"))
if state == nil then
return false
end
local idx = 10 * (8 - row) + col + 1
if state < 2 then
if H.propValue(p, "Selected") == true then
ledCol(idx, C.available)
else
ledOff(idx)
end
return true
end
local r, g, b
if state >= 6 then
r, g, b = C.red[1], C.red[2], C.red[3]
elseif state >= 3 then
r, g, b = C.green[1], C.green[2], C.green[3]
else
r, g, b = H.argb(clipColour(col, row))
end
if state >= 3 and not blinkPhase(CLIP_BLINK_FAST[state]) then
r, g, b = H.scale7(r * 0.18), H.scale7(g * 0.18), H.scale7(b * 0.18)
end
ledRGB(idx, r, g, b)
return true
end
local function paintChromaticGrid()
local cs = mpc.controlSurface
local pads = cs and cs.pads
local virt = pads and pads.virtual
for padRow = 0, 7 do
for col = 0, 7 do
local idx = 10 * (padRow + 1) + col + 1
local i = padRow * 8 + col
local p = (virt and virt[i]) or (pads and pads[i])
local v = H.call(p and p.GetColour)
if type(v) ~= "number" then
v = H.propValue(p, "Colour")
end
if type(v) == "number" and v ~= 0 and v ~= -16777216 then
local r, g, b = H.argb(v)
ledRGB(idx, H.scale7(r), H.scale7(g), H.scale7(b))
else
ledRGB(idx, 0, 15, 30)
end
end
end
end
local function paintPadsGrid(poll)
if padsLayout == "pads64" then
paintChromaticGrid()
return
end
local quadrant = {}
for i = 0, 15 do
quadrant[10 * (math.floor(i / 4) + 1) + (i % 4) + 1] = true
end
for row = 0, GRID_ROWS - 1 do
for col = 0, GRID_COLS - 1 do
local idx = 10 * (8 - row) + col + 1
if not quadrant[idx] then
ledOff(idx)
end
end
end
local pads = mpc.controlSurface and mpc.controlSurface.pads
for i = 0, 15 do
local idx = 10 * (math.floor(i / 4) + 1) + (i % 4) + 1
if poll then
local p = pads and pads[i]
local v = H.call(p and p.GetColour)
if type(v) ~= "number" then
v = H.propValue(p, "Colour")
end
if v ~= padsColourCache[i] then
padsColourCache[i] = v
local r, g, b = H.argb(v)
ledRGB(idx, H.scale7(r), H.scale7(g), H.scale7(b))
end
elseif type(padsColourCache[i]) == "number" then
local r, g, b = H.argb(padsColourCache[i])
ledRGB(idx, H.scale7(r), H.scale7(g), H.scale7(b))
end
end
end
local function paintGrid()
if padsMode then
paintPadsGrid(ticks % 2 == 0)
return
end
if tempoMode then
paintTempoGrid()
return
end
if swingMode then
paintSwingGrid()
return
end
if qlinkMode then
paintQlinkGrid()
return
end
if adjustMode then
paintAdjustGrid()
return
end
for row = 0, GRID_ROWS - 1 do
for col = 0, GRID_COLS - 1 do
local idx = 10 * (8 - row) + col + 1
if not (clipProps and paintClipSlot(col, row)) then
local status = clipStatus(col, row)
if status == 0 then
ledOff(idx)
else
local c = clipColour(col, row)
local r, g, b = H.argb(c)
local k = 1.0
if status == 1 then
k = 0.18
elseif status == 3 then
k = blinkOn and 0.9 or 0.18
elseif status == 2 then
k = 0.95
end
ledRGB(idx, H.scale7(r * k), H.scale7(g * k), H.scale7(b * k))
end
end
end
end
end
local function paintScene()
for row = 0, 7 do
local idx = SCENE[row + 1]
local state = nil
if aperture and aperture.sceneProperties and aperture.sceneProperties[row] then
state = H.propValue(aperture.sceneProperties[row], "State")
end
if state == S.Playing or state == S.Recording then
ledCol(idx, C.green)
elseif state == S.WillPlay or state == S.WillRecord then
ledRGB(
idx,
blinkOn and C.green[1] or C.dim[1],
blinkOn and C.green[2] or C.dim[2],
blinkOn and C.green[3] or C.dim[3]
)
else
ledCol(idx, C.dim)
end
end
end
local function paintTrack()
local function fnAvailable(fn)
if not H.projectLoaded() then
return false -- no project / dialog open: project-scoped menus are unavailable
end
if fn == "device" then
local cs = mpc.controlSurface
return (cs and cs.qlinks ~= nil) or (mpc.sequencer ~= nil and mpc.sequencer.SetBPM ~= nil)
elseif fn == "stopClip" then
return aperture ~= nil and aperture.StopClipsOnTrack ~= nil
end
return mpc.tracks ~= nil
end
local function fnColour(fn)
if
heldFunction == fn
or adjustMode == fn
or (fn == "device" and (tempoMode or qlinkMode))
or (fn == "stopClip" and swingMode)
then
return C.white
elseif fnAvailable(fn) then
return C.available
else
return C.off
end
end
local arm = fnColour("recArm")
local mute = fnColour("mute")
local solo = fnColour("solo")
local volume = fnColour("volume")
local pan = fnColour("pan")
local sends = fnColour("sends")
local device = fnColour("device")
local stopClip = fnColour("stopClip")
ledCol(TRACK.recArm, arm)
ledCol(TRACK.mute, mute)
ledCol(TRACK.solo, solo)
ledCol(TRACK.volume, volume)
ledCol(TRACK.pan, pan)
ledCol(TRACK.sends, sends)
ledCol(TRACK.device, device)
ledCol(TRACK.stopClip, stopClip)
for col = 0, 7 do
local gc = H.globalPos(col, 0)
local t = mpc.tracks and mpc.tracks.normalTracks and mpc.tracks.normalTracks[gc]
local r, g, b = C.dim[1], C.dim[2], C.dim[3]
if t then
if heldFunction == "mute" then
if H.propValue(t, "Mute") then
r, g, b = C.orange[1], C.orange[2], C.orange[3]
end
elseif heldFunction == "solo" then
if H.propValue(t, "Solo") then
r, g, b = C.yellow[1], C.yellow[2], C.yellow[3]
end
elseif heldFunction == "recArm" then
if H.propValue(t, "RecArm") then
r, g, b = C.red[1], C.red[2], C.red[3]
end
else
local c = H.propValue(t, "Colour")
if type(c) == "number" then
local cr, cg, cb = H.argb(c)
r, g, b = H.scale7(cr * 0.3), H.scale7(cg * 0.3), H.scale7(cb * 0.3)
end
end
end
if t then
ledRGB(101 + col, r, g, b)
else
ledOff(101 + col)
end
end
end
local padsLayoutAvailable -- forward declaration (defined with the pad-mode helpers)
local function paintTop()
local function modeColour(m)
if mode == m then
return C.white
else
return C.dim
end
end
local projectOn = H.projectLoaded()
local session = (not projectOn and C.off) or (followMode and C.cyan) or modeColour("clip")
local sequencer = modeColour("step")
local note = C.off
if padsMode then
note = (padsLayout == "pads64") and C.cyan or C.white
elseif padsLayoutAvailable() and H.projectLoaded() then
note = C.available
end
local chord = projectOn and C.available or C.off -- opens the MPC's Pad Perform page on press
local custom = C.off -- stub
ledCol(TOP.session, session)
ledCol(TOP.sequencer, sequencer)
ledCol(TOP.note, note)
ledCol(TOP.chord, chord)
ledCol(TOP.custom, custom)
local arrows = projectOn and C.white or C.off
ledCol(TOP.left, arrows)
ledCol(TOP.right, arrows)
local saveAvailable = mpc.controlSurface ~= nil and mpc.controlSurface.save ~= nil
if not projectOn then
ledCol(TOP.save, C.off)
else
ledCol(TOP.save, saveAvailable and C.available or C.dim)
end
ledRGB(
TOP.shift,
shift and C.white[1] or C.dim[1],
shift and C.white[2] or C.dim[2],
shift and C.white[3] or C.dim[3]
)
end
local function quantiserEnabled()
return H.truthy(H.propValue(mpc.sequencer and mpc.sequencer.quantiser, "Enabled"))
end
local function paintLeft()
local sq = mpc.sequencer
local playing = H.truthy(sq and H.call(sq.IsPlaying) or H.propValue(sq, "Playing"))
local recording = H.truthy(H.propValue(sq, "RecordState"))
local overdub = H.truthy(H.propValue(sq, "OverdubState"))
local loop = H.truthy(H.propValue(sq, "Loop"))
if playing then
ledCol(LEFT.play, C.green)
elseif loop then
ledCol(LEFT.play, C.orange)
else
ledCol(LEFT.play, C.dim)
end
if recording then
ledCol(LEFT.record, C.red)
elseif overdub then
ledCol(LEFT.record, C.orange)
else
ledCol(LEFT.record, C.dim)
end
ledOff(LEFT.fixedLength)
local quantizeAvailable = mpc.controlSurface ~= nil and mpc.controlSurface.quantizeApply ~= nil
if not quantizeAvailable then
ledCol(LEFT.quantize, C.off)
elseif quantiserEnabled() then
ledCol(LEFT.quantize, C.cyan) -- quantiser is on
else
ledCol(LEFT.quantize, C.white) -- available, quantiser off
end
local projectOn = H.projectLoaded()
local nudgeOn = adjustMode ~= nil or tempoMode or swingMode or qlinkMode
local pageColour = tempoMode and C.white
or (swingMode and C.yellow or (qlinkMode and qlinkColour(qlinkForColumn(0) or 0) or H.adjustColour()))
ledCol(LEFT.duplicate, projectOn and C.white or C.off)
ledCol(LEFT.clear, projectOn and C.white or C.off)
ledCol(LEFT.down, (not projectOn and C.off) or (nudgeOn and pageColour or C.white))
ledCol(LEFT.up, (not projectOn and C.off) or (nudgeOn and pageColour or C.white))
end
local function paintRight()
ledRGB(
RIGHT.logo,
probeMode and C.cyan[1] or C.dim[1],
probeMode and C.cyan[2] or C.dim[2],
probeMode and C.cyan[3] or C.dim[3]
)
end
paintAll = function()
paintGrid()
paintScene()
paintTrack()
paintTop()
paintLeft()
paintRight()
flushLEDs()
end
local listeners = {} -- every property listened to; stopped by removeListeners
local gridListeners = {} -- the current window's clip slots; rebound on window moves
local function listen(prop, fn, store)
if prop and type(prop.listen) == "function" then
local ok = pcall(function()
prop:listen(fn, deviceName)
end)
if ok then
local target = store or listeners
target[#target + 1] = prop
end
end
end
local function repaintFn(fn)
return function(...)
local ok, err = pcall(fn, ...)
if not ok then
H.logOnce("listenererror", "listener error: " .. tostring(err))
end
end
end
local function stopProps(props)
for _, prop in ipairs(props) do
if prop and type(prop.stopListening) == "function" then
pcall(function()
prop:stopListening(deviceName)
end)
end
end
end
local function listenGrid()
stopProps(gridListeners)
gridListeners = {}
if not clipProps then
return
end
for col = 0, GRID_COLS - 1 do
for row = 0, GRID_ROWS - 1 do
local p = clipProps[col] and clipProps[col][row]
if p then
local repaint = repaintFn(function()
paintGrid()
flushLEDs()
end)
listen(p.Colour, repaint, gridListeners)
listen(p.State, repaint, gridListeners)
listen(p.Selected, repaint, gridListeners)
end
end
end
end
local function followCurrentTrack(index)
if followMode and aperture and type(index) == "number" then
local normalCount = H.call(mpc.tracks and mpc.tracks.SizeNormalTracks) or 0
if index >= normalCount then
H.call(aperture.SetActiveMatrix, "Master")
H.call(aperture.MoveToColumn, index - normalCount)
else
H.call(aperture.SetActiveMatrix, "Normal")
H.call(aperture.MoveToColumn, index)
end
H.log("follow current track " .. tostring(index))
end
listenGrid()
padCache = {}
paintAll()
end
local function listenAll()
if aperture and aperture.sceneProperties then
for row = 0, 7 do
local p = aperture.sceneProperties[row]
if p then
listen(
p.State,
repaintFn(function()
paintScene()
flushLEDs()
end)
)
end
end
end
local tracks = mpc.tracks and mpc.tracks.normalTracks
if tracks then
for i = 0, 7 do
local t = tracks[i]
if t then
local repaint = repaintFn(function()
paintTrack()
flushLEDs()
end)
listen(t.Mute, repaint)
listen(t.Solo, repaint)
listen(t.RecArm, repaint)
end
end
end
local sq = mpc.sequencer
if sq then
local repaint = repaintFn(function()
paintLeft()
flushLEDs()
end)
listen(sq.Playing, repaint)
listen(sq.RecordState, repaint)
listen(sq.OverdubState, repaint)
listen(sq.Loop, repaint)
listen(sq.quantiser and sq.quantiser.Enabled, repaint)
end
local ct = mpc.tracks and mpc.tracks.currentTrack
if ct then
listen(
ct.Index,
repaintFn(function(newIndex)
followCurrentTrack(newIndex)
end)
)
end
followCurrentTrack(H.propValue(ct, "Index"))
end
local function removeListeners()
stopProps(gridListeners)
gridListeners = {}
stopProps(listeners)
listeners = {}
end
local function closeGridStates()
adjustMode = nil
tempoMode = false
swingMode = false
tempoHold = nil
swingHold = nil
clipOp = nil
clipOrigin = nil
lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
end
local function padsModeNote(i)
return 10 * (math.floor(i / 4) + 1) + (i % 4) + 1
end
local function pressSurfaceButton(name)
local press = H.callable(mpc.controlSurface and mpc.controlSurface[name], "Press")
if press then
H.call(press)
H.call(H.callable(mpc.controlSurface[name], "Release"))
return true
end
return false
end
padsLayoutAvailable = function()
local pads = dev.mappings and dev.mappings.pads
if not pads then
return false
end
local field = (padsLayout == "pads64") and "AddNoteToVirtualPad" or "AddNoteToMpcPad"
return H.callable(pads, field) ~= nil
end
local function openPadPerformPage()
if pressSurfaceButton("padPerform") then
H.log("pad perform page open on MPC")
else
H.logOnce("padperform", "padPerform unavailable on this MPC")
end
end
local function exitPadsMode()
if not padsMode then
return
end
padsMode = false
local m = dev.mappings and dev.mappings.script
local pads = dev.mappings and dev.mappings.pads
for _, b in ipairs(boundPadNotes) do
if b.pad then
H.call(pads and pads.RemoveNoteToMpcPad, 0, b.note, b.pad)
else
H.call(pads and pads.RemoveNoteToVirtualPad, 0, b.note)
end
H.call(m and m.AddNoteToScript, 0, b.note)
end
boundPadNotes = {}
padsColourCache = {}
if padsLayout == "pads64" then
if pressSurfaceButton("bank1") then
H.log("pad bank reset (bank 1)")
else
H.logOnce("bankreset", "pad bank reset unavailable: controlSurface.bank1 missing")
end
end
H.log("pads mode off")
end
chromaticVirtualPad = function(padRow, col)
return padRow * 8 + col
end
local function enterPadsMode()
local m = dev.mappings and dev.mappings.script
local pads = dev.mappings and dev.mappings.pads
if not (m and pads and m.RemoveNoteToScript) then
H.logOnce("padsmode", "pads mode unavailable: mappings.pads missing")
return
end
if padsLayout == "pads64" and type(pads.AddNoteToVirtualPad) ~= "function" then
H.logOnce("padschromatic", "chromatic layout unavailable: AddNoteToVirtualPad missing")
return
end
if padsLayout == "drum" and type(pads.AddNoteToMpcPad) ~= "function" then
H.logOnce("padsmode", "pads mode unavailable: AddNoteToMpcPad missing")
return
end
padsMode = true
padsColourCache = {}
boundPadNotes = {}
if padsLayout == "drum" then
if pressSurfaceButton("main") then
H.log("pad view: main screen")
else
H.logOnce("padview", "pad view reset unavailable: controlSurface.main missing")
end
end
if padsLayout == "pads64" then
for padRow = 0, 7 do
for col = 0, 7 do
local note = 10 * (padRow + 1) + col + 1
H.call(m.RemoveNoteToScript, 0, note)
H.call(pads.AddNoteToVirtualPad, 0, note, chromaticVirtualPad(padRow, col))
boundPadNotes[#boundPadNotes + 1] = { note = note }
end
end
else
for i = 0, 15 do
local note = padsModeNote(i)
H.call(m.RemoveNoteToScript, 0, note)
H.call(pads.AddNoteToMpcPad, 0, note, i)
boundPadNotes[#boundPadNotes + 1] = { note = note, pad = i }
end
end
H.log("pads mode on (" .. padsLayout .. ")")
if padsLayout == "pads64" then
H.logOnce("tip8x8", "tip: switch the MPC's pad view to 8x8 64 Pads for full colours")
end
end
local function firstLayoutForTrack()
local t = mpc.tracks and mpc.tracks.currentTrack
local trackType = H.propValue(t, "Type")
if type(trackType) == "string" and trackType ~= "" and trackType ~= "Drum" then
return "pads64", trackType
end
return "drum", trackType
end
local function togglePadsMode()
if not padsMode and not H.requireProject("pads mode") then
return
end
if not padsMode then
local layout, trackType = firstLayoutForTrack()
padsLayout = layout
H.log("track type " .. tostring(trackType or "?") .. " -> " .. layout)
closeGridStates()
enterPadsMode()
if padsMode then
paintPadsGrid(true) -- immediate mirror, independent of the tick parity
end
return
end
exitPadsMode()
paintAll()
end
local function setMode(m)
exitPadsMode() -- another mode (CC 93 session, CC 97, ...) always returns to the clip grid
mode = m
H.log("mode -> " .. m)
paintAll()
end
local function doClip(col, row)
if not aperture then
return
end
if shift then
H.call(aperture.SelectClip, col, row)
H.log(string.format("SelectClip(%d,%d)", col, row))
else
H.call(aperture.SelectClip, col, row)
H.call(aperture.TriggerClip, col, row)
H.log(string.format("TriggerClip(%d,%d)", col, row))
end
end
local function doScene(row)
if not aperture then
return
end
H.call(aperture.TriggerRow, row)
H.log("TriggerRow(" .. row .. ")")
end
local function handleRightLabel(row)
if row == 0 then
setMode("clip")
elseif row == 1 then
setMode("step")
elseif row == 2 then
setMode("track")
else
H.log("page " .. row .. ": TODO")
end
end
local function applyFunction(fn, idx)
local t = mpc.tracks and mpc.tracks.normalTracks and mpc.tracks.normalTracks[idx]
if not t then
H.logOnce("track", "no track " .. tostring(idx))
return
end
if fn == "recArm" then
local v = H.propValue(t, "RecArm")
H.call(t.SetRecArm, not v)
H.log("SetRecArm(" .. tostring(not v) .. ") track " .. idx)
elseif fn == "mute" then
local v = H.propValue(t, "Mute")
H.call(t.SetMute, not v)
H.log("SetMute(" .. tostring(not v) .. ") track " .. idx)
elseif fn == "solo" then
local v = H.propValue(t, "Solo")
H.call(t.SetSolo, not v)
H.log("SetSolo(" .. tostring(not v) .. ") track " .. idx)
elseif fn == "stopClip" then
H.call(aperture and aperture.StopClipsOnTrack, idx)
H.log("StopClipsOnTrack(" .. idx .. ")")
else
H.log(fn .. ": unsupported track function " .. idx)
end
end
local function selectTrack(col, gc)
local setCurrent = H.callable(mpc.tracks, "SetCurrentTrack")
if setCurrent then
H.call(setCurrent, gc)
H.log("SetCurrentTrack(" .. gc .. ")")
end
if aperture then
H.call(aperture.SelectTrack, col)
end
end
local function setTrackValue(idx, name, v)
local t = H.trackAt(idx)
if not t then
H.logOnce("track", "no track " .. tostring(idx))
return
end
local p = t[name]
if p == nil then
H.logOnce("prop" .. name, name .. " MISSING on track " .. tostring(idx))
return
end
local value = H.clamp01(v)
local ok = pcall(function()
p.value = value
end)
if not ok then
H.logOnce("set" .. name, "set " .. name .. " failed on track " .. tostring(idx))
return
end
H.log(string.format("%s track %d = %.3f", name, idx, value))
end
local function setTrackVolumeDB(idx, db)
local t = H.trackAt(idx)
if not t then
H.logOnce("track", "no track " .. tostring(idx))
return
end
local p = t.VolumeDB
if p ~= nil then
local ok = pcall(function()
p.value = db
end)
if ok then
H.log(string.format("VolumeDB track %d = %s", idx, tostring(db)))
return
end
end
setTrackValue(idx, "Volume", H.dbToGain(db))
end
local function changeTempo(delta)
if not H.requireProject("tempo") then
return
end
local sq = mpc.sequencer
local bpm = H.call(sq and sq.GetBPM) or 120
bpm = math.max(20, math.min(300, math.floor(bpm + delta + 0.5)))
H.call(sq and sq.SetBPM, bpm)
H.log("tempo: " .. bpm .. " BPM")
paintGrid()
paintLeft()
flushLEDs()
end
local function changeSwing(delta)
if not H.requireProject("swing") then
return
end
local q = mpc.sequencer and mpc.sequencer.quantiser
local swing = H.call(q and q.GetSwing) or 50
swing = math.max(50, math.min(75, math.floor(swing + delta + 0.5)))
H.call(q and q.SetSwing, swing)
H.log("swing: " .. swing .. "%")
paintGrid()
paintLeft()
flushLEDs()
end
local function doQuantize()
if not H.requireProject("quantize") then
return
end
local press = H.callable(mpc.controlSurface and mpc.controlSurface.quantizeApply, "Press")
if press then
H.call(press)
H.call(H.callable(mpc.controlSurface.quantizeApply, "Release"))
H.log("quantize applied")
else
H.logOnce("quantize", "quantize unavailable: controlSurface.quantizeApply missing")
end
end
local function nudgeAdjust(delta)
if not adjustMode then
return
end
local gc = H.globalPos(adjustCol, 0)
local name = H.adjustPropName()
if not name then
return
end
if adjustMode == "volume" then
local db = H.gainToDb(H.propValue(H.trackAt(gc), "Volume"))
local row = H.dbToRow(db)
if delta > 0 then
row = math.max(0, row - 1)
else
row = math.min(GRID_ROWS - 1, row + 1)
end
setTrackVolumeDB(gc, VOLUME_DB[row])
paintAll()
return
end
local cur = H.propValue(H.trackAt(gc), name)
if type(cur) ~= "number" then
cur = 0
end
setTrackValue(gc, name, cur + delta)
paintAll()
end
local function enterAdjust(newMode)
if not H.requireProject(newMode .. " menu") then
return
end
exitPadsMode() -- the fader menus need the whole grid
tempoMode = false
swingMode = false
qlinkMode = false
adjustMode = newMode
adjustCol = 0
lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
if newMode == "sends" then
adjustSend = 1
end
H.log("menu " .. newMode)
paintAll()
end
local function exitAdjust()
if adjustMode then
adjustMode = nil
lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
H.log("menu off")
paintAll()
end
end
local function handleAdjustPad(col, row)
if not adjustMode then
return
end
local gc = H.globalPos(col, 0)
if adjustMode == "volume" then
setTrackVolumeDB(gc, VOLUME_DB[row])
lastPadCol, lastPadRow, lastPadTick = col, row, ticks
adjustCol = col
paintAll()
return
end
local value = (GRID_ROWS - row) / GRID_ROWS
if col == lastPadCol and row == lastPadRow and ticks - lastPadTick <= 2 then
if row == GRID_ROWS - 1 then
value = 0
end
end
lastPadCol, lastPadRow, lastPadTick = col, row, ticks
adjustCol = col
local name = H.adjustPropName()
if name then
setTrackValue(gc, name, value)
paintAll()
end
end
local function doTapTempo()
local now = H.call(dev.timer and dev.timer.Now)
local useMs = type(now) == "number"
if not useMs then
now = ticks
end
local function diff(a, b)
local d = a - b
if useMs and d < 0 then
d = d + 4294967296 -- 32-bit wrap
end
return d
end
if #tapTicks > 0 and diff(now, tapTicks[#tapTicks]) > (useMs and 2000 or 40) then
tapTicks = {}
end
tapTicks[#tapTicks + 1] = now
if #tapTicks > 5 then
table.remove(tapTicks, 1)
end
if #tapTicks < 2 then
H.log("tap tempo: first tap")
return
end
local total = 0
for i = 2, #tapTicks do
total = total + diff(tapTicks[i], tapTicks[i - 1])
end
local avg = total / (#tapTicks - 1)
local bpm = (useMs and 60000 or 1200) / avg
bpm = math.max(20, math.min(300, bpm))
bpm = math.floor(bpm + 0.5) -- MPC BPM is an integer
local setBPM = H.callable(mpc.sequencer, "SetBPM")
if setBPM then
H.call(setBPM, bpm)
H.log(string.format("tap tempo: %d BPM (%.1f ms)", bpm, avg))
else
H.logOnce("tapbpm", "tap tempo unavailable: sequencer.SetBPM missing")
end
end
local function updateTapTempoRouting(held)
local m = dev.mappings and dev.mappings.script
local cs = dev.mappings and dev.mappings.controlSurface
if held and cs and type(cs.AddCCToControl) == "function" and type(cs.RemoveCCToControl) == "function" then
local ok = pcall(function()
m.RemoveCCToScript(0, TRACK.sends)
cs.AddCCToControl(0, TRACK.sends, "Tap Tempo")
end)
if ok then
nativeTap = true
H.logOnce("tapnative", "tap tempo: native")
return
end
end
if nativeTap then
H.call(cs and cs.RemoveCCToControl, 0, TRACK.sends)
H.call(m and m.AddCCToScript, 0, TRACK.sends)
nativeTap = false
elseif held then
H.call(m and m.AddCCToScript, 0, TRACK.sends)
end
if held then
H.logOnce("tapmanual", "tap tempo: manual fallback")
end
end
local function doShiftFunction(fn)
if fn == "recArm" then
local cm = mpc.commandManager
if cm and type(cm.Undo) == "function" then
H.call(cm.Undo)
H.log("Undo")
else
H.logOnce("undo", "Undo unavailable: commandManager.Undo missing")
end
elseif fn == "mute" then
local cm = mpc.commandManager
if cm and type(cm.Redo) == "function" then
H.call(cm.Redo)
H.log("Redo")
else
H.logOnce("redo", "Redo unavailable: commandManager.Redo missing")
end
elseif fn == "solo" then
local sq = mpc.sequencer
local me = H.propValue(sq, "MetronomeEnabled")
if sq and type(sq.SetMetronomeEnabled) == "function" then
H.call(sq.SetMetronomeEnabled, not me)
H.log("Metronome " .. tostring(not me))
else
H.logOnce("metronome", "metronome unavailable: sequencer.SetMetronomeEnabled missing")
end
elseif fn == "sends" then
if not nativeTap then
doTapTempo()
end
elseif fn == "device" then
if not tempoMode and not H.requireProject("tempo page") then
return
end
exitPadsMode() -- the tempo page needs the whole grid
adjustMode = nil
swingMode = false
qlinkMode = false
tempoMode = not tempoMode
tempoHold = nil
if tempoMode then
H.log("tempo page: " .. tostring(H.call(mpc.sequencer and mpc.sequencer.GetBPM)) .. " BPM")
else
H.log("tempo page off")
end
paintAll()
flushLEDs()
elseif fn == "stopClip" then
if not swingMode and not H.requireProject("swing page") then
return
end
exitPadsMode() -- the swing page needs the whole grid
adjustMode = nil
tempoMode = false
qlinkMode = false
tempoHold = nil
swingMode = not swingMode
swingHold = nil
if swingMode then
H.log(
"swing page: "
.. tostring(H.call(mpc.sequencer and mpc.sequencer.quantiser and mpc.sequencer.quantiser.GetSwing))
.. "%"
)
else
H.log("swing page off")
end
paintAll()
flushLEDs()
else
H.log(fn .. " shift: TODO")
end
end
local function doTransport(fn)
if not H.requireProject("transport") then
return
end
local sq = mpc.sequencer
if fn == "play" then
local playing = sq and H.call(sq.IsPlaying) or H.propValue(sq, "Playing")
if playing then
H.call(sq and sq.Stop)
H.log("Stop")
else
H.call(sq and sq.Play)
H.log("Play")
end
elseif fn == "record" then
H.call(sq and sq.Record)
H.log("Record")
end
end
local function recordArmed()
return H.truthy(H.propValue(mpc.sequencer, "RecordState"))
end
local function doRecordToggle()
if not H.requireProject("record") then
return
end
local armed = recordArmed()
if pressSurfaceButton("record") then
H.log("record: " .. (armed and "disarmed" or "armed"))
return
end
local name = armed and "RecordOff" or "Record"
local f = H.callable(mpc.sequencer, name)
if not f then
H.logOnce("record", "record unavailable: sequencer." .. name .. " missing")
return
end
H.call(f)
H.log("record: " .. (armed and "disarmed" or "armed"))
end
local function doLoopToggle()
if not H.requireProject("loop") then
return
end
local sq = mpc.sequencer
local loop = H.propValue(sq, "Loop")
if not sq or sq.Loop == nil then
H.logOnce("loop", "loop unavailable: sequencer.Loop missing")
return
end
local ok = pcall(function()
sq.Loop.value = not loop
end)
if not ok then
H.logOnce("loopwrite", "loop unavailable: sequencer.Loop.value not writable")
return
end
H.log("loop: " .. (loop and "off" or "on"))
end
local function doOverdub()
local f = H.callable(mpc.sequencer, "Overdub")
if not f then
H.logOnce("overdub", "overdub unavailable: sequencer.Overdub missing")
return
end
H.call(f)
H.log("overdub")
end
local function doAutomationFilterCycle()
if not H.requireProject("automation filter") then
return
end
local f = H.callable(mpc.project, "AdvanceGlobalAutomationFilterType")
if not f then
H.logOnce("autofilter", "automation filter unavailable: project.AdvanceGlobalAutomationFilterType missing")
return
end
H.call(f)
H.log("automation filter: cycled")
end
local function doTrackNav(forward)
local field = forward and "Next" or "Previous"
if H.trackAction(field, "tracknav", "track nav") then
H.log("track: " .. (forward and "next" or "prev"))
end
end
local function doPluginPreset(forward)
local field = forward and "NextPluginPreset" or "PrevPluginPreset"
if H.trackAction(field, "preset", "preset") then
H.log("preset: " .. (forward and "next" or "prev"))
end
end
local function moveWindow(dir, n)
if not aperture then
return
end
local fn = ({ left = "MoveLeft", right = "MoveRight", up = "MoveUp", down = "MoveDown" })[dir]
if fn then
H.call(aperture[fn], n)
H.log(fn .. "(" .. n .. ")")
padCache = {}
listenGrid() -- the slot properties follow the window: rebind, then repaint
paintAll()
end
end
local function probe(note, cc, value)
H.log(string.format("PROBE note=%s cc=%s value=%s", tostring(note), tostring(cc), tostring(value)))
if note then
ledCol(note, C.white)
end
if cc then
ledCol(cc, C.white)
end
flushLEDs()
end
local function noteIndex(note)
if note >= GRID_NOTE0 and note <= GRID_NOTE0 + 77 then
local i = note - GRID_NOTE0
local padRow = math.floor(i / 10)
local col = i % 10
if col < 8 and padRow < 8 then
return col, 7 - padRow -- col, MPC row (0 = top)
end
end
return nil
end
function LaunchpadProMK3.HandleMIDINoteOn(channel, note, velocity)
if channel ~= 0 then
return
end
if probeMode then
probe(note, nil, velocity)
return
end
local col, row = noteIndex(note)
if col then
if padsMode then
return -- a pad mode owns the grid; the unbound pads stay inert
end
if velocity > 0 then
if heldFunction == "stopClip" then
local gc = H.globalPos(col, 0)
H.call(aperture and aperture.StopClipsOnTrack, gc)
H.log("StopClipsOnTrack(" .. gc .. ")")
paintAll()
elseif clipOp == "clear" then
local gc, gr = H.globalPos(col, row)
H.call(mpc.clipMatrix and mpc.clipMatrix.DeleteClip, gc, gr)
H.log(string.format("DeleteClip(%d,%d)", gc, gr))
paintAll()
elseif clipOp == "duplicate" then
local gc, gr = H.globalPos(col, row)
if clipOrigin == nil then
clipOrigin = { gc, gr }
H.log(string.format("duplicate origin (%d,%d)", gc, gr))
else
H.call(mpc.clipMatrix and mpc.clipMatrix.CopyClip, clipOrigin[1], clipOrigin[2], gc, gr)
H.log(string.format("CopyClip(%d,%d -> %d,%d)", clipOrigin[1], clipOrigin[2], gc, gr))
paintAll()
end
elseif adjustMode then
handleAdjustPad(col, row)
elseif qlinkMode then
handleQlinkPad(col, row)
elseif not tempoMode and not swingMode then
doClip(col, row)
end
end
return
end
end
function LaunchpadProMK3.HandleMIDINoteOff(_channel, _note, _velocity)
end
local function ccShiftDown()
shift = false
updateTapTempoRouting(false)
paintTop()
flushLEDs()
end
local function ccRelease(cc)
if cc == TOP.shift then
ccShiftDown()
end
if cc == LEFT.clear or cc == LEFT.duplicate then
clipOp = nil
clipOrigin = nil
paintAll()
flushLEDs()
end
if cc == LEFT.up or cc == LEFT.down then
tempoHold = nil
swingHold = nil
end
local held = TRACK_FN[cc]
if held and held == heldFunction then
heldFunction = nil
paintTrack()
flushLEDs()
end
end
local function ccUpDown(delta)
if tempoMode then
tempoHold = (delta > 0) and LEFT.up or LEFT.down
tempoHoldTicks = 0
changeTempo(delta)
elseif swingMode then
swingHold = (delta > 0) and LEFT.up or LEFT.down
swingHoldTicks = 0
changeSwing(delta)
elseif adjustMode then
nudgeAdjust(delta / 8)
elseif qlinkMode then
if shift then
nudgeQlink(delta)
elseif qlinkPage == 0 and qlinkPageHasContent(1) then
qlinkPage = 1
H.log("qlink page 2")
paintAll()
elseif qlinkPage == 1 then
qlinkPage = 0
H.log("qlink page 1")
paintAll()
end
else
moveWindow((delta > 0) and "up" or "down", shift and 8 or 1)
end
end
local function armClipOp(kind)
clipOp = kind
clipOrigin = nil
H.log(
"clip op "
.. kind
.. " armed: "
.. (kind == "clear" and "press the clip pad" or "press origin pad, then target pad")
)
paintAll()
end
local function ccFunctionButton(fn)
if shift then
doShiftFunction(fn)
paintTrack()
flushLEDs()
elseif fn == "sends" then
if adjustMode == "sends" then
adjustSend = (adjustSend % 4) + 1
H.log("send " .. adjustSend)
paintAll()
else
enterAdjust("sends")
end
elseif fn == "volume" or fn == "pan" then
if adjustMode == fn then
exitAdjust()
else
enterAdjust(fn)
end
elseif fn == "device" then
if qlinkMode then
if qlinkPage == 0 and qlinkPageHasContent(1) then
qlinkPage = 1
H.log("qlink page 2")
paintAll()
else
exitQlink()
end
else
enterQlink()
end
else
heldFunction = fn
adjustMode = nil
H.log("hold " .. fn)
paintAll()
end
end
local function toggleFollow()
followMode = not followMode
H.log("follow: " .. (followMode and "on" or "off"))
if followMode then
followCurrentTrack(H.propValue(mpc.tracks and mpc.tracks.currentTrack, "Index"))
else
paintTop()
flushLEDs()
end
end
local function logStatus()
H.log("status: mode=" .. mode .. " shift=" .. tostring(shift))
end
local function toggleProbe()
probeMode = not probeMode
H.log("probe mode " .. tostring(probeMode))
paintRight()
flushLEDs()
end
local function stepSeqNext()
if pressSurfaceButton("stepSeqNext") then
H.log("step seq: next")
else
H.logOnce("stepseqnext", "step seq next unavailable: controlSurface.stepSeqNext missing")
end
end
local function openStepSeq()
if not H.requireProject("step seq") then
return
end
if pressSurfaceButton("stepSeq") then
setMode("step")
H.log("step seq view")
else
H.logOnce("stepseq", "step seq unavailable: controlSurface.stepSeq missing")
end
end
local function doSave()
if not H.requireProject("save") then
return
end
if pressSurfaceButton("save") then
H.log("save")
else
H.logOnce("save", "save unavailable: controlSurface.save missing")
end
end
local function shiftPress()
shift = true
updateTapTempoRouting(true)
paintTop()
flushLEDs()
end
local PRESS = {
[TOP.shift] = shiftPress,
[TOP.session] = function()
setMode("clip")
end,
[TOP.sequencer] = function()
if probeMode then
dumpSequenceProbe()
return
end
openStepSeq()
end,
[TOP.note] = function()
togglePadsMode()
paintAll()
end,
[TOP.chord] = openPadPerformPage,
[TOP.custom] = function()
H.logOnce("custom", "custom button: unmapped")
end,
[TOP.left] = function()
moveWindow("left", 1)
end,
[TOP.right] = function()
moveWindow("right", 1)
end,
[TOP.save] = function()
H.log("projects: TODO")
end,
[RIGHT.logo] = logStatus,
[LEFT.up] = function()
ccUpDown(1)
end,
[LEFT.down] = function()
ccUpDown(-1)
end,
[LEFT.play] = function()
doTransport("play")
end,
[LEFT.record] = doRecordToggle,
[LEFT.quantize] = doQuantize,
[LEFT.duplicate] = function()
armClipOp("duplicate")
end,
[LEFT.clear] = function()
armClipOp("clear")
end,
}
local SHIFT_PRESS = {
[TOP.session] = toggleFollow,
[TOP.sequencer] = stepSeqNext,
[TOP.note] = function()
doPluginPreset(false)
end,
[TOP.chord] = function()
doPluginPreset(true)
end,
[TOP.left] = function()
doTrackNav(false)
end,
[TOP.right] = function()
doTrackNav(true)
end,
[TOP.save] = doSave,
[RIGHT.logo] = toggleProbe,
[LEFT.play] = doLoopToggle,
[LEFT.record] = doOverdub,
[LEFT.fixedLength] = doAutomationFilterCycle,
}
for row = 0, 7 do
local sceneRow = row
PRESS[SCENE[sceneRow + 1]] = function()
doScene(sceneRow)
end
SHIFT_PRESS[SCENE[sceneRow + 1]] = function()
handleRightLabel(sceneRow)
end
end
for cc, fnName in pairs(TRACK_FN) do
local name = fnName
PRESS[cc] = function()
ccFunctionButton(name)
end
end
for cc = 101, 108 do
local col = cc - 101
PRESS[cc] = function()
local gc = H.globalPos(col, 0)
if heldFunction then
applyFunction(heldFunction, gc)
else
selectTrack(col, gc)
end
end
end
LaunchpadProMK3.ACTIONS = ACTIONS
LaunchpadProMK3.PALETTE = C
function LaunchpadProMK3.HandleMIDICC(channel, cc, value)
if channel ~= 0 then
return
end
if probeMode then
probe(nil, cc, value)
return
end
if value == 0 then
ccRelease(cc)
return
end
local action = (shift and SHIFT_PRESS[cc]) or PRESS[cc]
if action then
action()
return
end
H.log("unmapped CC " .. cc .. " value " .. value)
end
function LaunchpadProMK3.HandleMIDISysex(bytes)
if type(bytes) ~= "string" then
return
end
if bytes:byte(1) == 0xF0 then
bytes = bytes:sub(2)
end
if bytes:byte(-1) == 0xF7 then
bytes = bytes:sub(1, -2)
end
if
bytes:byte(1) == 0x7E
and bytes:byte(3) == 0x06
and bytes:byte(4) == 0x02
and bytes:sub(5, 7) == string.char(0x00, 0x20, 0x29)
then
local ver = {}
for i = 12, math.min(14, #bytes) do
ver[#ver + 1] = tostring(bytes:byte(i))
end
H.logOnce("firmware", "firmware: " .. (#ver > 0 and table.concat(ver, ".") or "unknown"))
end
if bytes:sub(1, 6) == string.char(0x00, 0x20, 0x29, 0x02, 0x0E, 0x00) and #bytes >= 9 then
local layout = bytes:byte(7)
local page = bytes:byte(8)
if priorLayout == nil and layout ~= 0x11 then
priorLayout, priorPage = layout, page
H.log(string.format("prior layout 0x%02x page %d", layout, page))
end
end
end
function LaunchpadProMK3.HandleTimer()
ticks = ticks + 1
if ticks % 5 == 0 then
blinkOn = not blinkOn
end
if tempoMode and tempoHold then
tempoHoldTicks = tempoHoldTicks + 1
local interval = tempoHoldTicks < 10 and 6 or (tempoHoldTicks < 20 and 3 or 1)
if tempoHoldTicks % interval == 0 then
changeTempo(tempoHold == LEFT.up and 1 or -1)
end
end
if swingMode and swingHold then
swingHoldTicks = swingHoldTicks + 1
local interval = swingHoldTicks < 10 and 6 or (swingHoldTicks < 20 and 3 or 1)
if swingHoldTicks % interval == 0 then
changeSwing(swingHold == LEFT.up and 1 or -1)
end
end
if layoutQuerySent and not programmerEntered and ticks >= 1 then
sendLayout(0x11, 0)
programmerEntered = true
H.log("programmer mode")
end
if aperture and not clipProps then
for _, n in ipairs({ "GetOriginX", "GetColumn", "GetX" }) do
local v = H.call(aperture[n])
if type(v) == "number" then
originCol = v
break
end
end
for _, n in ipairs({ "GetOriginY", "GetRow", "GetY" }) do
local v = H.call(aperture[n])
if type(v) == "number" then
originRow = v
break
end
end
end
if ticks % 40 == 0 then
padCache = {}
if padsMode then
padsColourCache = {} -- force a full quadrant resend every 2 s
end
end -- resend everything every 2 s
paintAll()
end
function LaunchpadProMK3.OnLoad()
adjustMode = nil
adjustSend = 1
tempoMode = false
swingMode = false
qlinkMode = false
qlinkPage = 0
qlinkCol = 0
followMode = false
padsMode = false
padsLayout = "drum"
padsColourCache = {}
clipOp = nil
clipOrigin = nil
aperture = dev.clipMatrixAperture or (mpc.clipMatrix and mpc.clipMatrix.clipMatrixAperture)
clipProps = (aperture and aperture.clipProperties)
or dev.clipProperties
or (mpc.clipMatrix and mpc.clipMatrix.clipProperties)
if aperture then
H.call(aperture.SetColumns, 8)
H.call(aperture.SetRows, 8)
H.call(aperture.SetLabel, "LPP3")
H.call(aperture.SetFollowsTUI, false)
H.call(aperture.Show)
H.log("aperture ok")
else
H.logOnce("noaperture", "aperture MISSING: clip surface disabled")
end
if clipProps then
H.log("clipProperties ok")
else
H.logOnce("noclips", "clipProperties MISSING")
end
local m = dev.mappings and dev.mappings.script
if m then
for padRow = 0, 7 do
for col = 0, 7 do
H.call(m.AddNoteToScript, 0, 10 * (padRow + 1) + col + 1)
end
end
local ccs = {
1,
2,
3,
4,
5,
6,
7,
8,
10,
19,
20,
29,
30,
39,
40,
49,
50,
59,
60,
69,
70,
79,
80,
89,
90,
91,
92,
93,
94,
95,
96,
97,
98,
99,
101,
102,
103,
104,
105,
106,
107,
108,
}
for _, cc in ipairs(ccs) do
H.call(m.AddCCToScript, 0, cc)
end
H.call(m.SetHandleSysex, true)
end
queryLayout()
layoutQuerySent = true
local okProbe = pcall(function()
dev.midiOut.SendMIDISysex(string.char(0x7E, 0x7F, 0x06, 0x01), port)
end)
if not okProbe then
H.logOnce("fwprobe", "firmware probe failed")
end
listenAll()
paintAll()
H.call(dev.timer and dev.timer.Start, 50)
H.log("loaded")
H.log(
"engine mode: "
.. tostring(
H.propValue(mpc.engineMode, "CurrentMode") or H.call(H.callable(mpc.engineMode, "GetCurrentMode"))
)
.. " popup: "
.. H.currentPopup()
)
end
function LaunchpadProMK3.OnUnload()
H.call(dev.timer and dev.timer.Stop)
removeListeners()
exitPadsMode() -- hand the pad-mode notes back to the script before unmapping
padsMode = false
padsColourCache = {}
adjustMode = nil
adjustSend = 1
tempoMode = false
swingMode = false
qlinkMode = false
qlinkPage = 0
qlinkCol = 0
clipOp = nil
clipOrigin = nil
if programmerEntered then
sendLayout(priorLayout or 0x04, priorPage or 0x00)
H.log("restored layout")
end
if nativeTap then
local cs = dev.mappings and dev.mappings.controlSurface
H.call(cs and cs.RemoveCCToControl, 0, TRACK.sends)
nativeTap = false
end
local m = dev.mappings and dev.mappings.script
if m then
for padRow = 0, 7 do
for col = 0, 7 do
H.call(m.RemoveNoteToScript, 0, 10 * (padRow + 1) + col + 1)
end
end
local ccs = {
1,
2,
3,
4,
5,
6,
7,
8,
10,
19,
20,
29,
30,
39,
40,
49,
50,
59,
60,
69,
70,
79,
80,
89,
90,
91,
92,
93,
94,
95,
96,
97,
98,
99,
101,
102,
103,
104,
105,
106,
107,
108,
}
for _, cc in ipairs(ccs) do
H.call(m.RemoveCCToScript, 0, cc)
end
end
for padRow = 0, 7 do
for col = 0, 7 do
ledOff(10 * (padRow + 1) + col + 1)
end
end
for _, cc in ipairs({
1,
2,
3,
4,
5,
6,
7,
8,
10,
19,
20,
29,
30,
39,
40,
49,
50,
59,
60,
69,
70,
79,
80,
89,
90,
91,
92,
93,
94,
95,
96,
97,
98,
99,
101,
102,
103,
104,
105,
106,
107,
108,
}) do
ledOff(cc)
end
flushLEDs()
if aperture then
H.call(aperture.Hide)
end
H.log("unloaded")
end
